package multilinecomment

/* Some comment here
	with my very own
		indentation as it pleases me */

func main() {
	if true {
		// code
	}
}
