package gh10

func foo() string {
	s := `foo`
	return s
}
